### Up and Running in No Time

#### Install Dependencies 
npm: `npm i`    
or    
yarn: `yarn install`

#### Start The Server
`nodemon` 